// Массив для хранения транзакций
export let tranzaktsii = [];

