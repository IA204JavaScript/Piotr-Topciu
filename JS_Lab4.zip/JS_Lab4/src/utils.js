import { tranzaktsii } from './transactions.js';

// Функция для расчета общей суммы
export function rasschitatObshuyuSummu() {
    const obshayaSumma = tranzaktsii.reduce((acc, t) => acc + t.summa, 0);
    document.getElementById('obshaya-summa').textContent = obshayaSumma;
}
