import { tranzaktsii } from './transactions.js';

// Функция для добавления строки в таблицу
export function dobavitTranzaktsiyu(tranzaktsiya, tablica) {
    const stroka = document.createElement('tr');
    stroka.dataset.id = tranzaktsiya.id;

    // Создаем ячейки
    const tdData = document.createElement('td');
    tdData.textContent = tranzaktsiya.data;

    const tdKategoriya = document.createElement('td');
    tdKategoriya.textContent = tranzaktsiya.kategoriya;

    const tdOpisanie = document.createElement('td');
    tdOpisanie.textContent = tranzaktsiya.opisanie.split(' ').slice(0, 4).join(' ');

    const tdDeystvie = document.createElement('td');
    const knopkaUdalit = document.createElement('button');
    knopkaUdalit.textContent = 'Удалить';
    knopkaUdalit.classList.add('btn-udalit');
    knopkaUdalit.dataset.id = tranzaktsiya.id;
    tdDeystvie.appendChild(knopkaUdalit);

    // Если сумма положительная - зеленый цвет, иначе - красный
    stroka.style.backgroundColor = tranzaktsiya.summa >= 0 ? '#d4ffd4' : '#ffd4d4';

    // Добавляем ячейки в строку
    stroka.appendChild(tdData);
    stroka.appendChild(tdKategoriya);
    stroka.appendChild(tdOpisanie);
    stroka.appendChild(tdDeystvie);

    // Добавляем строку в таблицу
    tablica.appendChild(stroka);
}

// Функция для удаления транзакции
export function udalytTranzaktsiyu(id, tablica) {
    const index = tranzaktsii.findIndex(t => t.id === id);
    if (index !== -1) {
        tranzaktsii.splice(index, 1);
        const stroka = tablica.querySelector(`tr[data-id="${id}"]`);
        if (stroka) tablica.removeChild(stroka);
    }
}

// Функция для отображения полного описания
export function pokazatPolnoeOpisanie(tranzaktsiya) {
    const blokOpisanie = document.getElementById('polnoe-opisanie');
    blokOpisanie.textContent = `Полное описание: ${tranzaktsiya.opisanie}`;
}
