import { tranzaktsii } from './transactions.js';
import { dobavitTranzaktsiyu, pokazatPolnoeOpisanie, udalytTranzaktsiyu } from './ui.js';
import { rasschitatObshuyuSummu } from './utils.js';

// Получаем элементы формы и таблицы
const formaTranzaktsii = document.getElementById('forma-tranzaktsii');
const tablicaTranzaktsii = document.getElementById('tablica-tranzaktsii').querySelector('tbody');

// Обработчик отправки формы
formaTranzaktsii.addEventListener('submit', (event) => {
    event.preventDefault();

    const novayaTranzaktsiya = {
        id: Date.now(),
        data: new Date().toLocaleString(),
        summa: parseFloat(document.getElementById('summa').value),
        kategoriya: document.getElementById('kategoriya').value,
        opisanie: document.getElementById('opisanie').value
    };

    tranzaktsii.push(novayaTranzaktsiya);
    dobavitTranzaktsiyu(novayaTranzaktsiya, tablicaTranzaktsii);
    rasschitatObshuyuSummu();
    formaTranzaktsii.reset();
});

// Обработчик кликов по таблице
tablicaTranzaktsii.addEventListener('click', (event) => {
    if (event.target.classList.contains('btn-udalit')) {
        const id = Number(event.target.dataset.id);
        udalytTranzaktsiyu(id, tablicaTranzaktsii);
        rasschitatObshuyuSummu();
    } else if (event.target.parentElement.tagName === 'TR') {
        const id = Number(event.target.parentElement.dataset.id);
        const tranzaktsiya = tranzaktsii.find(t => t.id === id);
        pokazatPolnoeOpisanie(tranzaktsiya);
    }
});
