var selectValyuta1 = document.getElementById("from");
var selectValyuta2 = document.getElementById("to");
var vvodSumma = document.getElementById("amount");
var knopka = document.getElementById("convert");
var rezultat = document.getElementById("result");
var knopkaObmen = document.getElementById("swap-btn");

var valyuty = ["USD", "EUR", "GBP", "MDL", "JPY"];

for (var i = 0; i < valyuty.length; i++) {     //заполняем выпадающие списки из переменноц валюты
  var opt1 = document.createElement("option");
  opt1.value = valyuty[i];
  opt1.text = valyuty[i];
  selectValyuta1.add(opt1);

  var opt2 = document.createElement("option");
  opt2.value = valyuty[i];
  opt2.text = valyuty[i];
  selectValyuta2.add(opt2);
}

selectValyuta1.value = "USD"; //валюты по умолчания
selectValyuta2.value = "MDL";

knopka.addEventListener("click", function () {  //запуск всего кода внутри функции и превращая в десятичное число
  var iz = selectValyuta1.value;
  var v = selectValyuta2.value;
  var summa = parseFloat(vvodSumma.value);x`x`

  if (isNaN(summa) || summa <= 0) {
    rezultat.textContent = "введите сумму больше 0";   // проверка числа, что бы не было меньше 0 и было число
    return;
  }

  var zapros = new XMLHttpRequest();   // Создаём новый запрос к серверу
  zapros.open("GET", "https://api.exchangerate-api.com/v4/latest/" + iz);   // Открываем GET-запрос к API с базовой валютой iz (например, "USD")

  zapros.onload = function () {   // Когда ответ от сервера получен, парсим JSON-строку в объект

    var dannye = JSON.parse(zapros.responseText);   // Когда ответ от сервера получен, парсим JSON-строку в объект

    var kurs = dannye.rates[v];    // Берём курс нужной валюты v (например, "EUR") из объекта rates

    var itog = summa * kurs;    // Умножаем введённую сумму summa на курс, получая итоговую сумму в валюте v

    rezultat.textContent = summa + " " + iz + " = " + itog.toFixed(2) + " " + v;    // Выводим результат в элемент с id или переменной rezultat, форматируем число с 2 знаками после запятой
  };
  zapros.send();
});


knopkaObmen.addEventListener("click", function () {
  var vremya = selectValyuta1.value;
  selectValyuta1.value = selectValyuta2.value;
  selectValyuta2.value = vremya; 
});
